#pragma once

namespace sdk
{
	class Collideable
	{

	public:

		virtual void unk0();
		virtual Vector &Mins() const;
		virtual Vector &Maxs() const;
	};
}