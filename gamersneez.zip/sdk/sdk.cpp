#include "../../includes.h"

#include "Checksum_CRC.h"

namespace sdk
{
	CCRC gCRC;
}